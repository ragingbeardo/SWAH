## Configuration
- shutErDown                    - this will as you may expect, turn off the mod
- supriseMe                     - if true, there will be no log outputs on the server console telling you the weather
- initialWinterChancePercentage - the configurable percentage that determines your odds at the start of the server
- rollingWinterChancePercentage - the configurable percentage that determines chance of snow at the start of each raid until it starts snowing