export enum Season
{
    WINTER = "Winter",
    SPRING = "Spring"
}