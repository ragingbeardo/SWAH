# Seasonal Weather at Home

With the new availability of snow in SPT, this mod will give you a customizable chance of snow being active when you first start the server. The weather will only potenially change on the next server restart.

## Configuration
3 Simple fields:
- shutErDown             - this will as you may expect, turn off the mod
- supriseMe              - if true, there will be no log outputs on the server console telling you the weather
- winterChancePercentage - the configurable percentage that determines your odds

# Installation

1. Download the .7z file from the latest release
2. Copy the user folder from inside the archive into your SPT Directory
3. Profit